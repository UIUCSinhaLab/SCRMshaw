#!/usr/bin/perl
use strict;

=head1 Description

    This script is used to do the enrichment test
    for the hits results from SCRMshaw. Specifically,
    the test will be performed between genes nearest 
    to top-scored windows and expression gene set.
    Please note that currently this version has only
    been tested on Dmel, and therefore it is highly
    recommended to run it with the same parameter
    settings in the toy example (see './runs').


=head1 Usage

    perl wrap_enrichments.pl [options] HitsFile TestToPerform ExpressionGeneSet MapCRM2ExpresGeneSet Outdir

    --rt <str>              a directory that has dmel's CRM training set, this will be used to remove known CRMs in the hits results. mandatory input
    --dmelUni               dmel's universal gene set, mandatory input
    --dmelUniFB             dmel's universal FB gene set, mandatory input
    --redflygff             redfly gff file, mandatory input
    --th                    how many nearest genes to report for the enrichment test, default=200

    HitsFile                a directory that has hits results for each CRM training set
    TestToPerform           specify what universal gene set to use. For now please use 'dmel_test'
    ExpressionGeneSet       a directory that has expression gene sets
    MapCRM2ExpresGeneSet    a mapping file that shows the corresponding expression gene set to each CRM training set
    Outdir                  output directory

=head1 Example
    
   perl wrap_enrichments.pl -rt ../data/CRMtrainSet/ -dmelUni ../data/universalGeneSet/dmel_universe_cg.genes -dmelUniFB ../data/universalGeneSet/dmel_universe_FB_cg.genes -redflygff ../data/redfly_crm.gff ../data/hits/ dmel_test ../data/expressionGeneSet/ ../data/mappingCRM2expreGeneSet.txt ./runs/enrich 

=cut

use FindBin qw($Bin);
use Getopt::Long;

#my $tophowmany  =   undef;
my $tophits     =   undef;
my $remove_training     = undef;    ## for removing training data from hit file
my $weighted_hypergeo   =undef;
my $dmel_universal = undef;     ## dmel universal gene set
my $dmel_universal_FB = undef;  ## dmel FB uinversal gene set
my $redfly_gff = undef;         ## redfly gff file

GetOptions(
#    "top=i" => \$tophowmany,        ## 2000
	"rt=s" => \$remove_training,    ## /home/weiyang4/project/scrm/crms/dmel/
	"th=i" => \$tophits,
	"wh" => \$weighted_hypergeo,
    "dmelUni=s"=>\$dmel_universal,
    "dmelUniFB=s"=>\$dmel_universal_FB,
    "redflygff=s"=>\$redfly_gff
); 

die `pod2text $0` unless (@ARGV == 5 && $dmel_universal && $dmel_universal_FB && $redfly_gff);

#if(!defined($tophowmany)){$tophowmany =1000;}
if(!defined($tophits)){$tophits =200;}

my $pdir = $ARGV[0];        ## /home/chen192/MultiSpecies/MspGenome/Dmel_out_nv/ 
my $universe = $ARGV[1];    ## dmel_test 
my $edir = $ARGV[2];        ## /home/chen192/MultiSpecies/DownloadedData/Dmel/GeneSets/STRICT/testCGGeneSets/
my $mapfile = $ARGV[3];     ## /home/chen192/MultiSpecies/DownloadedData/Dmel/data/testSetCG.txt 
#my $bestmethodFile = $ARGV[4];  ## /home/chen192/MultiSpecies/DownloadedData/Dmel/data/dsmethodmap_msIMM.txt 
my $outdir = $ARGV[4];      ## /home/chen192/MultiSpecies/DownloadedData/Dmel/enrichment_nv/STRICT/msIMM/testSet/

print "pdir = $pdir\n";
print "universe = $universe\n";
print "edir = $edir\n";
print "mapfile = $mapfile\n";
#print "bestmethod = $bestmethodFile\n";
print "outdir = $outdir\n";

mkdir($outdir);     ## testSet

##========= read method =============##
#my %bestmethod;
#open(B,"<$bestmethodFile");     ## dsmethodmap_msIMM.txt
#while (<B>) {
#    chomp;
#    my ($dsname, $method) = split(/\s+/);   ## mapping0.ap, msIMM
#    $bestmethod{$dsname} = $method;         ## bestmethod{mapping0.ap} = msIMM
#}
#close(B);

##========== read map of crm train set ===========##
my @pfiles;
my %pemap;
open(M,"<$mapfile");        ## testSetCG.txt
while (<M>) {
    chomp;
    my ($pfile, @efiles) = split(/\s+/);    ## mapping0.ap, (blastoderm_ap_2004_FB.genes, blastoderm_ap_2010_FB.genes)
    push @pfiles, $pfile;                   ## @pfiles, mapping0.ap
    foreach my $efile (@efiles) {
	    if ($efile !~ /\?/) {
	        push @{$pemap{$pfile}}, $efile;     ## @{$pemap{mapping0.ap}}, blastoderm_ap_2004_FB.genes
	    }
    }
}
close(M);


foreach my $methodmode ('1') {  ## only loop once
    my $ext = $methodmode;
    if(defined($weighted_hypergeo)){    ## undef
	    $ext = "wh";
    }
    $ext = "wh"; # force the $ext to be "wh" even there's no weithed. Modified on 3/12
    ##========= define output file name ============##
    my $outfile = "$outdir/results.$ext\.txt";
    my $outfile2 = "$outdir/rawdata.$ext\.txt";
    my $outfile3 = "$outdir/overlapping_genes.txt";
    my $outfile5 = "$outdir/predicted_genes.txt";

    open(OUT, ">$outfile");
    open(OUT2, ">$outfile2");
    open(OUT3, ">$outfile3");
    open(OUT5, ">$outfile5");

    # my $methodname = "";
    foreach my $pfile (@pfiles) {                   ## mapping0.ap
	    if (!defined($pemap{$pfile})) { next; }     ## return 0
        #    if ($methodmode == '1') {                   ## return 1
        #    if (!defined($bestmethod{$pfile})) { next; }    ## return 0
            #        $methodname = $bestmethod{$pfile};      ## methodname = msIMM
#	    }
	    print OUT "$pfile";     ## mapping0.ap >> results.wh.txt
	    print OUT2 "$pfile";    ## mapping0.ap >> rawdata.wh.txt
        my @efiles = @{$pemap{$pfile}};     ## @efiles = (blastoderm_ap_2004_FB.genes, ...)
	    
        foreach my $efile (@efiles) {       ## blastoderm_ap_2004_FB.genes
            my $allgenesfile = $universe;   ## allgenesfile = dmel_test
            my $territory = undef;
            my $territory_FB = undef;
            
             #============= Dmel ============##
             #============== test ===========##
            if ($universe =~ /dmel_test/){     ## return 1
	            $allgenesfile = $dmel_universal;    ## 5570
	            if ($efile =~ /FB/) {   ## if blastoderm_ap_2004_FB.genes has "FB"
		            $allgenesfile = $dmel_universal_FB; ## 12892
	            }
                #    $territory = "/home/chen192/MultiSpecies/DownloadedData/Dmel/GeneSets/STRICT/universeGeneSets/dmel.territory";       ## 5540, won't be used in the followed steps
                #    $territory_FB = "/home/chen192/MultiSpecies/DownloadedData/Dmel/GeneSets/STRICT/universeGeneSets/dmel_FB.territory";     ## 12796, won't be used in the followed steps
             }
             ##============= train ===========##
             if ($universe =~ /dmel_train/){
		        $allgenesfile = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Dmel/GeneSets/STRICT/universeGeneSets/dmel_universe_FB_cg.genes";
                $territory = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Dmel/GeneSets/STRICT/universeGeneSets/dmel.territory";
                $territory_FB = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Dmel/GeneSets/STRICT/universeGeneSets/dmel_FB.territory"; 
             }

             #=============== Amel ============##
            if ($universe =~ /amel_test/){
	            $allgenesfile = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Amel/GeneSets/STRICT/universeGeneSets/amel_universe.genes";
	            if ($efile =~ /FB/) {
		            $allgenesfile = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Amel/GeneSets/STRICT/universeGeneSets/amel_universe_FB.genes";
	            }
                $territory = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Amel/GeneSets/STRICT/universeGeneSets/amel.territory";
                $territory_FB = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Amel/GeneSets/STRICT/universeGeneSets/amel_FB.territory"; 

             }

             if ($universe =~ /amel_train/)
             {
		$allgenesfile = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Amel/GeneSets/STRICT/universeGeneSets/amel_universe_FB.genes";
                $territory = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Amel/GeneSets/STRICT/universeGeneSets/amel.territory";
                $territory_FB = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Amel/GeneSets/STRICT/universeGeneSets/amel_FB.territory"; 
             }

             #============== Agam ==============##
             if ($universe =~ /agam_test/)
             {
	        $allgenesfile = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Agam/GeneSets/STRICT/universeGeneSets/agam_universe.genes";
	        if ($efile =~ /FB/) {
		$allgenesfile = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Agam/GeneSets/STRICT/universeGeneSets/agam_universe_FB.genes";
	        }
                $territory = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Agam/GeneSets/STRICT/universeGeneSets/agam.territory";
                $territory_FB = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Agam/GeneSets/STRICT/universeGeneSets/agam_FB.territory"; 
             }

             if ($universe =~ /agam_train/)
             {
		$allgenesfile = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Agam/GeneSets/STRICT/universeGeneSets/agam_universe_FB.genes";
                $territory = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Agam/GeneSets/STRICT/universeGeneSets/agam.territory";
                $territory_FB = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Agam/GeneSets/STRICT/universeGeneSets/agam_FB.territory"; 
             }

             #============== Aaeg ==================##
             if ($universe =~ /aaeg_test/)
             {
	        $allgenesfile = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Aaeg/GeneSets/STRICT/universeGeneSets/aaeg_universe.genes";
	        if ($efile =~ /FB/) {
		$allgenesfile = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Aaeg/GeneSets/STRICT/universeGeneSets/aaeg_universe_FB.genes";
	        }
                $territory = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Aaeg/GeneSets/STRICT/universeGeneSets/aaeg.territory";
                $territory_FB = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Aaeg/GeneSets/STRICT/universeGeneSets/aaeg_FB.territory"; 
             }

             if ($universe =~ /aaeg_train/)
             {
		$allgenesfile = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Aaeg/GeneSets/STRICT/universeGeneSets/aaeg_universe_FB.genes";
                $territory = "/home/sinhas/chen190/MultiSpecies/DownloadedData/Aaeg/GeneSets/STRICT/universeGeneSets/aaeg.territory";
                $territory_FB = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Aaeg/GeneSets/STRICT/universeGeneSets/aaeg_FB.territory"; 
             }

             #================== Nvit ==================##
             if ($universe =~ /nvit_test/)
             {
	        $allgenesfile = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Nvit/GeneSets/STRICT/universeGeneSets/nvit_universe.genes";
	        if ($efile =~ /FB/) {
		$allgenesfile = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Nvit/GeneSets/STRICT/universeGeneSets/nvit_universe_FB.genes";
	        }
                $territory = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Nvit/GeneSets/STRICT/universeGeneSets/nvit.territory";
                $territory_FB = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Nvit/GeneSets/STRICT/universeGeneSets/nvit_FB.territory"; 
             }

             if ($universe =~ /nvit_train/)
             {
		$allgenesfile = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Nvit/GeneSets/STRICT/universeGeneSets/nvit_universe_FB.genes";
                $territory = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Nvit/GeneSets/STRICT/universeGeneSets/nvit.territory";
                $territory_FB = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Nvit/GeneSets/STRICT/universeGeneSets/nvit_FB.territory"; 
             }

             #=================== Tcas ==================##
             if ($universe =~ /tcas_test/)
             {
	        $allgenesfile = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Tcas/GeneSets/STRICT/universeGeneSets/tcas_universe.genes";
	        if ($efile =~ /FB/) {
		$allgenesfile = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Tcas/GeneSets/STRICT/universeGeneSets/tcas_universe_FB.genes";
	        }
                $territory = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Tcas/GeneSets/STRICT/universeGeneSets/tcas.territory";
                $territory_FB = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Tcas/GeneSets/STRICT/universeGeneSets/tcas_FB.territory"; 
             }

             if ($universe =~ /tcas_train/)
             {
		$allgenesfile = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Tcas/GeneSets/STRICT/universeGeneSets/tcas_universe_FB.genes";
                $territory = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Tcas/GeneSets/STRICT/universeGeneSets/tcas.territory";
                $territory_FB = "/home/sinhas/chen192/MultiSpecies/DownloadedData/Tcas/GeneSets/STRICT/universeGeneSets/tcas_FB.territory"; 
             }

            ##========== run test_enrichment.corrected.pl =============##
	        if(defined($remove_training)){  ## /home/sinhas/chen192/MultiSpecies/MspGenome/Dmel_out_nv/
                print "R: $allgenesfile\n"; ## dmel_universe_cg.genes
                print "R: $efile\n";        ## blastoderm_ap_2004_FB.genes 
		        system("$Bin/enrichment.overlapGene.pvalue.pl -redflygff $redfly_gff -top $tophits -rt $remove_training/$pfile/crms.fasta  $allgenesfile $pdir/$pfile/$pfile.hits $edir/$efile $outdir/tmp.sample $outdir/tmp.gs $outdir/tmp.overlaps > $outdir/tmp.res");     ## 12892    745 200 60
	        }   
            ##=========== won't run these steps ============##
            else{
                print "NR: $allgenesfile\n";
                print "NR: $efile\n";
		        system("$Bin/enrichment.overlapGene.pvalue.pl -top $tophits $allgenesfile $pdir/$pfile/$pfile.hits $edir/$efile $outdir/tmp.sample $outdir/tmp.gs $outdir/tmp.overlaps > $outdir/tmp.res");
	        }
	    
	        #=========== won't run weighted hypergeometric test =============##
	        my $whg_pval="";
	        if(defined($weighted_hypergeo)){    ## undef
		        if($efile =~ /FB/ || $universe =~ /train/){
			        $whg_pval = `$Bin/HyperGeo $territory_FB $outdir/tmp.gs $outdir/tmp.sample`;
		        }
                else{
			        $whg_pval = `$Bin/HyperGeo $territory $outdir/tmp.gs $outdir/tmp.sample`;
		        }	
		        chomp($whg_pval);
	        }
	        ##========== read tmp.res ==============##
	        open(IN, "<$outdir/tmp.res");
	        my $nums = <IN>;
	        chomp($nums);
	        my ($N, $n, $m, $k) = split(/\s+/,$nums);   ## 12892, 745, 200, 60
	        my $pval = <IN>;    ## pval = 1.83439542511814e-27
	        chomp($pval);
	        close(IN);
	        printf OUT2 "\t$efile\t$N,$n,$m,$k";    ## rawdata.wh.txt << blastoderm_ap_2004_FB.genes, 12892, 745, 200, 60 -> for each Expression Gene Set
            if (!defined($weighted_hypergeo)){      ## return 1
                $whg_pval = $pval;          ## whg_pval = 1.83439542511814e-27
            }
            my @numlist = split(',', $whg_pval);    ## @numlist = 1.83439542511814e-27
            printf OUT "\t%s\t%.2g",($efile,@numlist[$#numlist]);   ## results.wh.txt << blastoderm_ap_2004_FB.genes, 1.83439542511814e-27


	        print OUT3 "$pfile\t$efile\n";  ## overlapping_genes.txt << mapping0.ap, blastoderm_ap_2004_FB.genes
	        open(IN, "<$outdir/tmp.overlaps");
	        my @overlaping_genes = <IN>;        ## CG7925
	        print OUT3 @overlaping_genes;       ## overlapping_genes.txt << CG7925 

            print OUT5 "$pfile\t$efile\n";      ## predicted_genes.txt << mapping0.ap, blastoderm_ap_2004_FB.genes
            open(IN, "<$outdir/tmp.sample");    
            my @sample_genes = <IN>;            ## CG7925
            print OUT5 @sample_genes;           ## predicted_genes.txt << CG7925 

	        close(IN);
	    }
	    print OUT "\n";
    	print OUT2 "\n";
	    print OUT3 "\n";
	    print OUT5 "\n";
    }
    close(OUT);
    close(OUT2);
    close(OUT3);
    close(OUT5);
}
