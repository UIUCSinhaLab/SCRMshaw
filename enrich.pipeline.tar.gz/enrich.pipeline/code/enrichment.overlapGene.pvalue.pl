#!/usr/bin/perl
use strict;
#use lib '/shared-mounts/sinhas/lib/';

=head1 Description

    This script will find out the overlapped
    genes between nearest genes of top-scored
    windows and the expression gene sets. And
    a hypergeometric test will also be performed
    for the universal gene, expression gene, 
    nearest gene and the overlapped genes.

=head1 Usage
    
    perl enrichment.overlapGene.pvalue.pl [options] UniversalGeneSet HitsFile ExpresGeneSet tmp.samlple tmp.gs tmp.overlaps

    --top           how many nearest genes to top-scored windows to report, default=200
    --rt            dmel's CRM training set, this will be used to remove known CRMs from hits file
    --redflygff     redfly gff file

    UniversalGeneSet    dmel's universal gene set
    HitsFile            hits file
    ExpresGeneSet       expression gene set
    tmp.samlple         intermediate file, nearest genes
    tmp.gs              intermediate file, expression genes
    tmp.overlaps        intermediate file, overlapped genes

=cut

use Bio::SeqIO;
use Getopt::Long;
use File::Basename;
use FindBin qw($Bin);

my $tophits = undef;
my $remove_training =undef; ## directory to the trainig crms 
my $INF =1000000000;        ## positive inf
my $redfly_gff = undef;     ## redfly gff file

GetOptions(
    "top=i" => \$tophits,   ## 200
	"rt=s" => \$remove_training, ## /home/weiyang4/project/scrm/crms/dmel/mapping0.ap
    "redflygff=s"=>\$redfly_gff
);

die `pod2text $0` unless (@ARGV == 6 && $redfly_gff);

if(!defined($tophits)) {$tophits = 200;}  # original value was 1000

my $exprgenes = $ARGV[0];   # dmel_universe_cg.genes
my $fhits = $ARGV[1];       # /home/sinhas/chen192/MultiSpecies/MspGenome/Dmel_out_nv/mapping0.ap/hits_msIMM_2000.txt
my $gs = $ARGV[2];    # /home/sinhas/chen192/MultiSpecies/DownloadedData/Dmel/GeneSets/STRICT/testCGGeneSets/blastoderm_ap_2004_FB.genes
my $sampleout = $ARGV[3] ;  # /home/sinhas/chen192/MultiSpecies/DownloadedData/Dmel/enrichment_nv/STRICT/msIMM/tmp.sample
my $gsout =$ARGV[4];        # /home/sinhas/chen192/MultiSpecies/DownloadedData/Dmel/enrichment_nv/STRICT/msIMM/tmp.gs
my $overlapsout = $ARGV[5]; # /home/sinhas/chen192/MultiSpecies/DownloadedData/Dmel/enrichment_nv/STRICT/msIMM/tmp.overlaps

#my $outdir = $sampleout;
#$outdir =~ s/tmp.sample//g;
#my $trainSetName = (split /\//,$fhits)[-2];
#my $expreGeneName;
#my $sampleCrmOut = $sampleout.".crm";
#open OUT1,">>$sampleCrmOut";

##======= get the coordinates of training crms and remove all the hits that overlaps with them ===========##
my %tcrms_loc=(); ## hash training crm locations
if(defined($remove_training)){  ## return 1
    # my $redfly_gff = $redfly_gff_file; ## coordinates are release4
    open(GFF,"<$redfly_gff");
    my %redflycrms=();
    while (<GFF>) {
	    chomp;
        my ($chr, $d1, $d2, $start, $stop, $d3, $d4, $d5, $desc) = split(/\s+/); ## 2L  REDfly  regulatory_region   2455781 2457764 .   .   .   ID="dpp_intron2"; Dbxref="Flybase ...
        $desc =~ /ID=\"([^\"]+)\"/;
        my $modname = $1;                       ## modname = dpp_intron2
        $modname =~ s/[^a-zA-Z0-9\_]//g;        ## modname = dpp_intron2
	    my $newstart = int($start/50)*50-500;   ## newstart = start - 500
	    my $newstop = int($stop/50)*50+500;     ## newstop = stop + 500
	    $redflycrms{$modname} = "$chr:$newstart:$newstop";  ## redflycrms{intron2} = 2L:newstart:newstop
    }
    close(GFF);
    my $crmTrain = Bio::SeqIO->new(-file=>$remove_training,-format=>'Fasta');
    # my @trainingcrms = <$remove_training/*.fna>; ## @trainingcrms = (tll_P2.fna,...)
    while (my $crm = $crmTrain->next_seq()){
        #foreach my $tc(@trainingcrms){
        #  $tc=basename($tc);      ## tc = tll_P2.fna
        my $title= $crm->id();
        #$tc =~/(.*)\.fna/;      
        #my $tcname = $1;        ## tcname = tll_P2
	    my $tcname = $title;
        if(exists($redflycrms{$tcname})){       ## redflycrms{tll_P2}
	        my($chr, $start, $stop)=split(/:/,$redflycrms{$tcname});   ## 2L, newstart, newstop
	        for(my $i=$start;$i<=$stop;$i+=50){     ## every 50bp for an increment, not 100% cover
		        $tcrms_loc{"$chr:$i"}=1;        ## tcrms_loc{2L:newstart} = 1
	        }
	    }
    }
}
##============= read Universe Gene Set ===============##
my %exprgenes=();
open(G,"<$exprgenes");  ## dmel_universe_cg.genes
while (<G>) {
    if (/^\#/) { next; }
    my ($cg) = split(/\s+/);    ## CG10045
    $exprgenes{$cg} = 1;        ## exprgenes{CG10045} = 1 
}
close G;
my %allgenes=%exprgenes;        ## allgenes = exprgenes
##=============== read Expression Gene Set ===============##
my %geneset=();
#foreach my $gs (@genesets)      ## only one Expression Gene Set in this array 
#{
    open(G,"<$gs");             ## blastoderm_ap_2004_FB.genes
    #   $expreGeneName = (split /\//,$gs)[-1];
    while (<G>) {
        if (/^\#/) {next;}
        chomp;
        my ($cg) = split(/\s+/);    ## CG10016
        if (!defined($allgenes{$cg})) {next;}   ## return 0 if CG10016 in dmel_universe_cg.genes
        $geneset{$cg} = 1;          ## geneset{CG10016} = 1
    }
    close G;
#}

#my $sampleCrmOut = $trainSetName.".".$expreGeneName;
#open OUT1,">$outdir/$sampleCrmOut";

my @geneset = keys %geneset;    ## @geneset = (CG10016, ...)
my $overlapcnt = 0;
my $countecrs = 0;
my $counthits = 0;
my %hits=();

##=============== read hits file ==================##
my $fo = Bio::SeqIO->new(-file=>$fhits,-format=>'Fasta');   ## hits_msIMM_2000.txt

while (my $f = $fo->next_seq()) 
{
    my $id = $f->id();      ## na_armX_genomic_dmel_RELEASE5.FASTA:2332500
    my $desc = $f->desc();  ## 30.7676 CG7925:tko:3846:downstream,CG7894:boi:5700:downstream
    my ($score, $genes) = split(/\s+/,$desc);   ## 30.7676, CG7925:tko:3846:downstream,CG7894:boi:5700:downstream 
    my @genes = split(",",$genes);  ## @genes = (CG7925:tko:3846:downstream, CG7894:boi:5700:downstream)
    my $mindist = $INF;     ## mindist = 1000000000
    my $nbrgene = undef;
    my $chr;
    my $t1;
    my $t2;
    my $loc;
    ##============ dmel =============##
    if($id=~/(\S+)\:.*/){
	    $chr = $1;          ## chr = 2L
        ($t2, $loc) = split(/:/, $id);  ## na_armX_genomic_dmel_RELEASE5.FASTA, 2332500
    }
    ##=========== agam =============##
    if ($id =~ /agam-(\S+)\.fasta.*/){
        $chr = $1;
        ($t2, $loc) = split(/:/, $id);
    }

    if ($id =~ /(supercont\S+)\.fasta.*/){
        $chr = $1;
        ($t2, $loc) = split(/:/, $id);
    }


    #============ Amel ===========##
    if ($id =~ /(Group\S+)\.fa.*/){
        $chr = $1;
        ($t2, $loc) = split(/:/, $id);
    }

    #============== Nvit ===========##
    if ($id =~ /(\S+)\.fasta.*/){
        $chr = $1;
        ($t2, $loc) = split(/:/, $id);
    }

    #============= Tcas =============##
    if ($id =~ /(\S+)\.fasta.*/){
        $chr = $1;
        ($t2, $loc) = split(/:/, $id);
    }
    
    ##========= next if tcrms_loc{2L:2332500} = 1, remove crm train seq =============##
    ##========= this changes the results when not allow re-assign of same genes to windows,
    ##========= because if its crm is filtered in this step, than this gene will never
    ##========= show up in top200 gene list, or the overlap list
    if(exists($tcrms_loc{"$chr:$loc"})){
	    next;
    }
    #   if ($fhits =~ /mapping0\.dv/){
    #    print OUT1 "$desc\n";
    #}
    ##=========== record nearest gene ===============##
    foreach my $gene (@genes) {     ## (CG7925:tko:3846:downstream, CG7894:boi:5700:downstream)
	    my @fields = split(/:/,$gene);  ## @fields = CG7925, tko, 3846, downstream
	    my $cg = $fields[0];            ## cg = CG7925
	    $cg =~ s/\-[PR].$//g;           
	    my $dist = $fields[$#fields-1]; ## dist = 3846


	    if ($dist < $mindist){  ## return 1
	        $mindist = $dist;   ## mindist = 3846, find out the min distance from 2 genes
	        $nbrgene = $cg;     ## nbrgene = CG7925
	    }
    }

    if (!defined($nbrgene)) {next;}     ## defined
    if (!defined($allgenes{$nbrgene})) {next;}  ## defined in dmel_universe_cg.genes
    
    if (!defined($hits{$nbrgene})) {    ## return 1 if undef
	    $hits{$nbrgene} = 1;            ## hits{CG7925} = 1, one nearest gene only report once
	    $counthits++;                   ## counthits ++
    }
    
    $countecrs++;                       ## countecrs ++
    if ($counthits >= $tophits) {last;} ## last when counthits >= 200
}


my @allgenes = keys %allgenes;      ## @allgenes = CG10045...
my $N = $#allgenes+1;               ## N = number of genes in Universe

##======= output Expression Gene Set ==========##
my @geneset = keys %geneset;        ## @geneset = CG10016...
open (OUT, ">$gsout");              ## tmp.gs
foreach my $g (keys %geneset) {
    print OUT "$g\n";               ## CG10016
}
close(OUT);
my $n = $#geneset+1;                ## n = number of genes in Expression Gene Set
##======== output 200 nearest gene ==========##
my @hits = keys %hits;              ## @hits = CG7925...
open (OUT, ">$sampleout");          ## tmp.sample
foreach my $h (keys %hits) {
    print OUT "$h\n";               ## CG7925
}
close(OUT);
my $m = $#hits+1;                   ## m = 200
##======== output overlap gene ==========##
my $k = 0;
open (OUT, ">$overlapsout");        ## tmp.overlaps
foreach my $hit (keys %hits) {    
    if (defined($geneset{$hit})) {  ## if 200 gene in Expression Gene Set
	    $k++;                       ## k = number of overlap
	    print OUT "$hit\n";         ## CG7925
        #    print OUT1 "$hit\n";
    }
}
close(OUT);

#close(OUT1);

print "$N\t$n\t$m\t$k\n";
system("$Bin/calPvalue.pl $N $n $m $k");

