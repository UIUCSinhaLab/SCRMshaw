#!/usr/bin/perl

if (@ARGV != 4){
	print "Usage: calPvalue.pl <N> <K> <n> <k>\n";
	exit;
}

my $N = shift(@ARGV);
my $K = shift(@ARGV);
my $n = shift(@ARGV);
my $k = shift(@ARGV);

if ($N < $K){ print "Error: N=$N < K=$K\n"; exit; }
if ($n < $k){ print "Error: n=$n < k=$k\n"; exit; }
if ($N < $n){ print "Error: N=$N < n=$n\n"; exit; }
if ($K < $k){ print "Error: K=$K < k=$k\n"; exit; }

if ($k == 0) { print "1.0\n"; exit; }
	
my $i;
my $rtn = 0;
for($i=$k; $i<=$n; $i++) {
	if ($K<$i || ($N-$K)<($n-$i)) { next; }
	$rtn = $rtn + exp(combine($K, $i)+combine(($N-$K), ($n-$i))-combine($N, $n));
}
print "$rtn\n";


# calculate c(n,m) = n!/(m!(n-m)!)
sub combine {
	my $N = $_[0];
	my $m = $_[1];
	if ($m == 0) { return 0.0; }
	if ($m == $N) {return 0.0; }
	
	my $i;
	my $rtn = 0;
	for($i=$N; $i>($N-$m); $i--) {
		$rtn = $rtn + log($i);
	}
	for($i=$m; $i>1; $i--) {
		$rtn = $rtn - log($i);
	}
	return $rtn;
}
