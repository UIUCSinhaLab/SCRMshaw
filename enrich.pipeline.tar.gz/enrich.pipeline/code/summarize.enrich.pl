use strict;
use warnings;

=head1 Description

    This script is to summarize the enrichment results
    and generate a table that is in the same fashion 
    as TableS2 in GBE's paper.

=head1 Usage
    
    perl summarize.enrich.pl TableS2 EnrichmentRawTable > EnrichTable

=cut

die `pod2text $0` unless @ARGV==2;

my $tableS2 = $ARGV[0];
my $enrichOut = $ARGV[1];

my %crm2expre = ();
open TS,$tableS2;
while (<TS>){
    chomp(my $line = $_);
    my ($crm, $expre) = split /\s+/,$line;
    $crm2expre{$crm} = $expre;
}
close TS;

my %hyper = ();
my %duplic = ();
my @crmName;
open EO,$enrichOut;
while (<EO>){
    chomp(my $line = $_);
    my @a = split /\s+/,$line;
    my $crm = (split /\./,$a[0],2)[1];
    if ($a[0] =~ /2/){
        $crm = $crm.".2";
    }
    if ($crm2expre{$crm}){
        push @crmName,$crm;
        my $expre = $crm2expre{$crm};
        for (my $i=1; $i<=$#a; $i++){
            if ($a[$i] eq $expre){
                $hyper{$crm} = $a[$i+1];
            }
        }
    }
}
close EO;

for my $name (@crmName){
    print "$name\t$hyper{$name}\n";
}
