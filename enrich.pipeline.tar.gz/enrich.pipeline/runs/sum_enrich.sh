## to run this code on your own data, please change './enrich/rawdata.wh.txt' to your enrichment result file, and './enrich/enrich.table.txt' to your output file name
perl ../code/summarize.enrich.pl ../data/tableS2.trainSet.ExpreGeneSet ./enrich/rawdata.wh.txt > ./enrich/enrich.table.txt
