#!/usr/bin/perl

=head1 Description

This file accepts a FASTA file of a genome, 
and outputs separated FASTA file for each sequence in the input.

=head1 Usage

    perl genome2chr.pl [Options] FASTA EXON OUTDIR

    FASTA       Fasta file.
    OUTDIR      output directory

    --exon <str>    Input exon file to mask exons on the target sequences, file format(tab delimited): chr start stop strand symbol

=cut

use strict;
use FindBin qw($Bin $Script);
use lib "$Bin/../lib";
#use Bio::SeqIO;
use Getopt::Long;
use File::Basename;

my $Exon;

GetOptions(
    "exon:s"=>\$Exon
);


my $ffile   = $ARGV[0];		## Input FASTA file.
#my $xfile	= $ARGV[1];		## Exon file.
my $odir	= $ARGV[1];		## Output directory for each chr.
my %seen	= ();			## Hash of chrs seen.
my %keep	= ();			## Hash of chrs to keep.
my %exons	= ();			## Hash of chrs to exon start and stop.


## Check exit conditions
die `pod2text $0` if (@ARGV != 2);

## Read gene file to get which crhs have genes.
#warn "reading exon file...\n";
if ($Exon)
{
    open(IFILE,$Exon) or die("Couldn't open exon file: $Exon for reading\n");
    while (my $line = <IFILE>) {
        chomp($line);
		my ($chr, $start, $stop, $strand, $gene) = split(/\s+/,$line);
		$keep{$chr} = 1;
        ($start,$stop)=($stop,$start) if ($start > $stop);
        push @{$exons{$chr}}, "$start:$stop";
    }
}
close(IFILE);

## Process each sequence in the fasta file.
#warn "reading fasta file...\n";
open (FA,$ffile) or die("Couldn't open fasta file: $ffile\n");
$/=">";<FA>;$/="\n";
while (<FA>)
{
    my $title=$_;
    my $chr=(split /\s+/,$title)[0];
    $/=">";
    my $seq=<FA>;
    chomp $seq;
    $/="\n";
    $seq =~ s/\s+//g;
    $seq =~ tr/atgc/ATGC/;
    my $len = length($seq);
    if ($Exon && !defined($keep{$chr}))  { next;}
    if (defined($seen{$chr}))   { next;}
	$seen{$chr} = 1;
#	print STDERR "$chr\n";
	my $ofile_dir	=	"$odir/$chr.fasta";
    my $ofile   =   "$chr.fasta";
    open(OFILE,">$ofile_dir") or die("Couldn't open $ofile for writing\n");
    print OFILE "\>$chr\n";
    if ($Exon)
    {
	    foreach my $exon (@{$exons{$chr}}) {
	        my ($start, $stop) = split(":",$exon);
            substr($seq,$start-1,$stop-$start) =~ tr/ATGC/N/;
	    }
    }
    for (my $i = 0; $i < $len; $i += 60) {
        print OFILE substr($seq, $i, 60)."\n";
    }
    close(OFILE);
}


