#ifndef _BUILD_IMM_H
#define _BUILD_IMM_H

void procOpts (int argc, char * argv []);
static void usage (char * command);

#endif
